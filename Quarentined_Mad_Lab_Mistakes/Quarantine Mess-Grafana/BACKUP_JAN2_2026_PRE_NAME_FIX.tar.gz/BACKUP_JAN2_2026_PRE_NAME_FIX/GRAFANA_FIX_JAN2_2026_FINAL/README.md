# Grafana Fix Session - January 2, 2026
## WORKING CONFIGURATION - DO NOT DELETE

### What's Working:
✅ All 7 Docker containers running (mosquitto, telegraf, influxdb, grafana, portainer, loki, suricata)
✅ InfluxDB initialized: Organization "Mad_Hub", Bucket "Mad_Team"
✅ MQTT data flowing with all Pi metrics (temp, cpu, mem, disk, throttle, voltage)
✅ Docker container metrics collecting
✅ Internet ping working (8.8.8.8, 1.1.1.1, 192.168.1.1)
✅ Device ping working (all Pis)
✅ Speedtest configured (runs every 15 minutes)
✅ Pi-hole script returns clean zeros (no JSON errors)

### InfluxDB Token (CRITICAL - DO NOT LOSE):
owI3GftJwbKC45FgqHa5fiAn2DxTuivt_jMHGiH3PWfUfnaac59bhrXY4x9_fOGT0q7y4BQ-9yTTeL4NE13Ihg==

### Files in This Backup:
1. docker-compose.yml - All 7 services with proper networking
2. telegraf.conf - Updated with correct token, docker input, speedtest wrapper
3. pihole_stats.sh - Returns clean zeros (Pi-hole v6 API auth not configured)
4. speedtest_wrapper.sh - Calls /usr/bin/speedtest-cli --json on host

### InfluxDB Measurements Available:
- mqtt_consumer (fields: temp, freq, cpu_pct, mem_used, mem_total, mem_pct, swap, disk_used, disk_total, disk_pct, uptime_secs, throttle, voltage)
- docker_container_cpu
- docker_container_mem
- docker_container_net
- docker_container_blkio
- docker_container_status
- internet_ping (fields: average_response_ms, minimum_response_ms, maximum_response_ms, packets_received, packets_transmitted, percent_packet_loss)
- device_ping (same fields as internet_ping)
- speedtest (fields: download, upload, ping)
- pihole (fields: queries_total, queries_blocked, percent_blocked - all zeros until API auth configured)

### Grafana Access:
URL: http://192.168.1.188:3000
Login: admin / rebootlabs
Data Source: InfluxDB (use token above)

### Key Flux Query Examples:

#### Throttle Status:
```flux
from(bucket: "Mad_Team")
  |> range(start: v.timeRangeStart, stop: v.timeRangeStop)
  |> filter(fn: (r) => r._measurement == "mqtt_consumer")
  |> filter(fn: (r) => r._field == "throttle")
  |> filter(fn: (r) => r.topic =~ /rbl\/sensors\//)
```

#### Internet Ping:
```flux
from(bucket: "Mad_Team")
  |> range(start: v.timeRangeStart, stop: v.timeRangeStop)
  |> filter(fn: (r) => r._measurement == "internet_ping")
  |> filter(fn: (r) => r._field == "average_response_ms")
```

#### CPU Temperature:
```flux
from(bucket: "Mad_Team")
  |> range(start: v.timeRangeStart, stop: v.timeRangeStop)
  |> filter(fn: (r) => r._measurement == "mqtt_consumer")
  |> filter(fn: (r) => r._field == "temp")
  |> filter(fn: (r) => r.topic =~ /rbl\/sensors\//)
```

### Throttle Value Meanings:
- 0 = ✅ HEALTHY (no issues)
- 327680 (0x50000) = ⚠️ Undervoltage + throttling occurred in the PAST (not currently)
- 327685 (0x50005) = ⚠️ Currently under-voltage + past issues

### Next Steps to Fix Grafana Panel Legends:
1. Edit panel query to add alias/label by topic
2. Use group by topic to separate each Pi
3. Add field overrides for proper units and display names

### Restore Instructions:
If anything breaks, copy these files back:
```bash
cp ~/GRAFANA_FIX_JAN2_2026_FINAL/docker-compose.yml ~/
cp ~/GRAFANA_FIX_JAN2_2026_FINAL/telegraf.conf ~/telegraf/
cp ~/GRAFANA_FIX_JAN2_2026_FINAL/pihole_stats.sh ~/telegraf/
cp ~/GRAFANA_FIX_JAN2_2026_FINAL/speedtest_wrapper.sh ~/telegraf/
docker-compose down
docker-compose up -d
docker restart telegraf
```

### Session End: January 2, 2026 - 1:56 PM
