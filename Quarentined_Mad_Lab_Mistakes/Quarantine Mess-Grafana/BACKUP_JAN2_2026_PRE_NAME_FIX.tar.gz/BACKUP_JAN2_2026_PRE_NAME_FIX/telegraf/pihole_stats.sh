#!/bin/bash
# Pi-hole v6 requires authentication - return zeros until auth is configured
# This prevents JSON parsing errors in Telegraf
echo '{"queries_total":0,"queries_blocked":0,"percent_blocked":0,"queries_cached":0,"queries_forwarded":0,"unique_domains":0}'
