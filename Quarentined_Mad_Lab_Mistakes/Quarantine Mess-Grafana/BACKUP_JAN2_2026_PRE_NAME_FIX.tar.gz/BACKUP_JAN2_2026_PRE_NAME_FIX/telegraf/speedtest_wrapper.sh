#!/bin/bash
# Speedtest wrapper - runs on HOST, called by Telegraf container
/usr/bin/speedtest-cli --json 2>/dev/null || echo '{"download":0,"upload":0,"ping":0}'
