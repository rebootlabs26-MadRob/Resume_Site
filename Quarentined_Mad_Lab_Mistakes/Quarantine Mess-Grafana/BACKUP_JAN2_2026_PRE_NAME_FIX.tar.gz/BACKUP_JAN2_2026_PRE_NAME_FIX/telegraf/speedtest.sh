#!/bin/bash
# Run speedtest and output JSON for Telegraf
RESULT=$(speedtest-cli --json 2>/dev/null)

if [ $? -eq 0 ]; then
  DOWNLOAD=$(echo "$RESULT" | grep -o '"download": [0-9.]*' | cut -d' ' -f2)
  UPLOAD=$(echo "$RESULT" | grep -o '"upload": [0-9.]*' | cut -d' ' -f2)
  PING=$(echo "$RESULT" | grep -o '"ping": [0-9.]*' | cut -d' ' -f2)
  
  # Convert to Mbps (speedtest returns bits/sec)
  DL_MBPS=$(echo "scale=2; $DOWNLOAD / 1000000" | bc)
  UL_MBPS=$(echo "scale=2; $UPLOAD / 1000000" | bc)
  
  echo "{\"download_mbps\":$DL_MBPS,\"upload_mbps\":$UL_MBPS,\"ping_ms\":$PING}"
else
  echo "{\"download_mbps\":0,\"upload_mbps\":0,\"ping_ms\":0}"
fi
